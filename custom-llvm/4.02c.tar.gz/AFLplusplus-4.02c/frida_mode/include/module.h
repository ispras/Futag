#ifndef _MODULE_H
#define _MODULE_H

#include "frida-gumjs.h"

void module_config(void);

void module_init(void);

#endif

